import React from "react";
import ReactDOM from "react-dom/client";
import EVLock from "./EVLock";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <EVLock />
  </React.StrictMode>
);
