import { useState, useEffect, useRef, useCallback } from "react";

const MARKETS = [
  { id: 1, name: "Will Bitcoin exceed $150K by Dec 2026?", category: "Crypto", entryPrice: 0.38, currentPrice: 0.62, shares: 420, side: "YES", emoji: "₿" },
  { id: 2, name: "US recession declared by Q3 2026?", category: "Economy", entryPrice: 0.25, currentPrice: 0.41, shares: 800, side: "YES", emoji: "📉" },
  { id: 3, name: "GPT-5 released before July 2026?", category: "AI", entryPrice: 0.72, currentPrice: 0.88, shares: 300, side: "YES", emoji: "🤖" },
  { id: 4, name: "Democrats win 2026 midterms (House)?", category: "Politics", entryPrice: 0.55, currentPrice: 0.47, shares: 600, side: "YES", emoji: "🏛" },
  { id: 5, name: "Tesla stock above $500 EOY 2026?", category: "Stocks", entryPrice: 0.30, currentPrice: 0.52, shares: 500, side: "YES", emoji: "⚡" },
  { id: 6, name: "FIFA World Cup 2026 — Brazil wins?", category: "Sports", entryPrice: 0.18, currentPrice: 0.22, shares: 1200, side: "YES", emoji: "⚽" },
];

const formatMoney = (v) => {
  const abs = Math.abs(v);
  return (v < 0 ? "-" : "") + "$" + abs.toFixed(2);
};
const formatPct = (v) => (v >= 0 ? "+" : "") + (v * 100).toFixed(1) + "%";

function calcHedge(entryPrice, currentPrice, shares, side) {
  // Max If Win: hedge just enough to break even on loss, maximize upside on win
  const cost = entryPrice * shares;
  const potentialPayout = shares * 1.0;
  const profitIfWin = potentialPayout - cost;
  const oppositePrice = 1 - currentPrice;

  if (oppositePrice <= 0 || oppositePrice >= 1) return null;

  const oppositeOdds = 1 / oppositePrice;
  // Solve for break-even if original loses: H * (oppositeOdds - 1) - cost = 0
  const hedgeStake = cost / (oppositeOdds - 1);
  const ifWin = profitIfWin - hedgeStake;
  const ifLose = hedgeStake * (oppositeOdds - 1) - cost; // ≈ 0

  if (ifWin <= 0) return null;

  return {
    hedgeStake: hedgeStake,
    hedgeSide: side === "YES" ? "NO" : "YES",
    hedgePrice: oppositePrice,
    guaranteedProfit: ifWin, // profit if you win (best case); break-even if you lose
    ifOriginalWins: ifWin,
    ifOriginalLoses: Math.max(ifLose, 0), // ≈ $0 (break-even)
    profitIfNoHedge: profitIfWin,
    roi: ifWin / cost,
    freeRoll: true, // can't lose, full upside preserved minus small hedge cost
  };
}

function PriceTicker({ price, prev }) {
  const dir = price > prev ? "up" : price < prev ? "down" : "flat";
  return (
    <span style={{
      fontFamily: "'JetBrains Mono', 'SF Mono', monospace",
      fontWeight: 700,
      fontSize: 15,
      color: dir === "up" ? "#00ff88" : dir === "down" ? "#ff4466" : "#c0c0c0",
      transition: "color 0.3s",
    }}>
      {(price * 100).toFixed(1)}¢
      <span style={{ fontSize: 10, marginLeft: 3, opacity: 0.7 }}>
        {dir === "up" ? "▲" : dir === "down" ? "▼" : "–"}
      </span>
    </span>
  );
}

function MiniSparkline({ history }) {
  if (!history || history.length < 2) return null;
  const w = 80, h = 24;
  const min = Math.min(...history);
  const max = Math.max(...history);
  const range = max - min || 0.01;
  const points = history.map((v, i) => {
    const x = (i / (history.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  }).join(" ");
  const last = history[history.length - 1];
  const first = history[0];
  const color = last >= first ? "#00ff88" : "#ff4466";
  return (
    <svg width={w} height={h} style={{ display: "block" }}>
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ProgressRing({ pct, size = 40, stroke = 3, color = "#00ff88" }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (Math.min(Math.max(pct, 0), 1)) * circ;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1a1f2e" strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.5s ease" }} />
    </svg>
  );
}

export default function EVLock() {
  const [markets, setMarkets] = useState(MARKETS);
  const [priceHistory, setPriceHistory] = useState(() => {
    const h = {};
    MARKETS.forEach(m => { h[m.id] = [m.currentPrice]; });
    return h;
  });
  const [prevPrices, setPrevPrices] = useState(() => {
    const p = {};
    MARKETS.forEach(m => { p[m.id] = m.currentPrice; });
    return p;
  });
  const [autoHedge, setAutoHedge] = useState(true);
  const [hedgeThreshold, setHedgeThreshold] = useState(15);
  const [minProfit, setMinProfit] = useState(5);
  const [activityLog, setActivityLog] = useState([]);
  const [hedgedPositions, setHedgedPositions] = useState({});
  const [selectedMarket, setSelectedMarket] = useState(null);
  const [simSpeed, setSimSpeed] = useState(1);
  const [isRunning, setIsRunning] = useState(true);
  const [tab, setTab] = useState("portfolio");
  const logRef = useRef(null);

  const addLog = useCallback((msg, type = "info") => {
    setActivityLog(prev => [{
      time: new Date().toLocaleTimeString(),
      msg,
      type,
      id: Date.now() + Math.random()
    }, ...prev].slice(0, 100));
  }, []);

  // Price simulation
  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setMarkets(prev => {
        const updated = prev.map(m => {
          const volatility = 0.008 + Math.random() * 0.012;
          const drift = (Math.random() - 0.48) * volatility;
          let newPrice = m.currentPrice + drift;
          newPrice = Math.max(0.03, Math.min(0.97, newPrice));
          return { ...m, currentPrice: Math.round(newPrice * 1000) / 1000 };
        });
        return updated;
      });
    }, 2000 / simSpeed);
    return () => clearInterval(interval);
  }, [isRunning, simSpeed]);

  // Track price history + prev prices
  useEffect(() => {
    setPriceHistory(prev => {
      const next = { ...prev };
      markets.forEach(m => {
        next[m.id] = [...(prev[m.id] || []), m.currentPrice].slice(-30);
      });
      return next;
    });
    setPrevPrices(prev => {
      const next = {};
      markets.forEach(m => { next[m.id] = prev[m.id] ?? m.currentPrice; });
      return next;
    });
  }, [markets]);

  // Auto-hedge engine
  useEffect(() => {
    if (!autoHedge || !isRunning) return;
    markets.forEach(m => {
      if (hedgedPositions[m.id]) return;
      const priceMove = ((m.currentPrice - m.entryPrice) / m.entryPrice) * 100;
      if (priceMove < hedgeThreshold) return;
      const hedge = calcHedge(m.entryPrice, m.currentPrice, m.shares, m.side);
      if (!hedge) return;
      if (hedge.guaranteedProfit < minProfit) return;

      setHedgedPositions(prev => ({ ...prev, [m.id]: {
        ...hedge,
        hedgedAt: m.currentPrice,
        timestamp: new Date().toLocaleTimeString(),
      }}));
      addLog(
        `FREE ROLL: ${m.name.slice(0, 40)}… — ${hedge.hedgeSide} $${hedge.hedgeStake.toFixed(2)} @ ${(hedge.hedgePrice * 100).toFixed(1)}¢ → Win: $${hedge.guaranteedProfit.toFixed(2)} / Lose: $0`,
        "hedge"
      );
    });
  }, [markets, autoHedge, hedgeThreshold, minProfit, hedgedPositions, isRunning, addLog]);

  const manualHedge = (m) => {
    const hedge = calcHedge(m.entryPrice, m.currentPrice, m.shares, m.side);
    if (!hedge) {
      addLog(`Cannot hedge "${m.name.slice(0, 35)}…" — no profit to lock`, "error");
      return;
    }
    setHedgedPositions(prev => ({ ...prev, [m.id]: {
      ...hedge,
      hedgedAt: m.currentPrice,
      timestamp: new Date().toLocaleTimeString(),
    }}));
    addLog(
      `MANUAL FREE ROLL: ${m.name.slice(0, 35)}… — Win: $${hedge.guaranteedProfit.toFixed(2)} / Lose: $0`,
      "hedge"
    );
  };

  const removeHedge = (id) => {
    setHedgedPositions(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    addLog(`Removed hedge on market #${id}`, "warn");
  };

  const totalCost = markets.reduce((s, m) => s + m.entryPrice * m.shares, 0);
  const totalValue = markets.reduce((s, m) => s + m.currentPrice * m.shares, 0);
  const totalPnL = totalValue - totalCost;
  const totalLocked = Object.entries(hedgedPositions).reduce((s, [, h]) => s + h.guaranteedProfit, 0);
  const hedgedCount = Object.keys(hedgedPositions).length;

  const selected = selectedMarket ? markets.find(m => m.id === selectedMarket) : null;
  const selectedHedge = selected ? calcHedge(selected.entryPrice, selected.currentPrice, selected.shares, selected.side) : null;
  const selectedHedged = selected ? hedgedPositions[selected.id] : null;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0e17",
      color: "#e0e4ec",
      fontFamily: "'DM Sans', 'Helvetica Neue', sans-serif",
      padding: 0,
      margin: 0,
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0d1220; }
        ::-webkit-scrollbar-thumb { background: #1e2a3a; border-radius: 3px; }
        @keyframes slideIn { from { opacity:0; transform:translateY(-8px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.5; } }
        @keyframes glow { 0%,100% { box-shadow: 0 0 8px rgba(0,255,136,0.15); } 50% { box-shadow: 0 0 20px rgba(0,255,136,0.3); } }
        .card { background: #111827; border: 1px solid #1e2a3a; border-radius: 12px; }
        .btn { cursor:pointer; border:none; border-radius:8px; font-family:inherit; font-weight:600; transition:all 0.15s; }
        .btn:hover { filter: brightness(1.15); transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }
        .row-hover:hover { background: #151d2e !important; }
      `}</style>

      {/* Header */}
      <div style={{
        background: "linear-gradient(180deg, #0f1520 0%, #0a0e17 100%)",
        borderBottom: "1px solid #1a2030",
        padding: "16px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 38, height: 38,
            background: "linear-gradient(135deg, #00ff88 0%, #00cc6a 100%)",
            borderRadius: 10,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontWeight: 800, fontSize: 16, color: "#0a0e17",
            fontFamily: "'JetBrains Mono', monospace",
          }}>EV</div>
          <div>
            <div style={{
              fontSize: 20, fontWeight: 700,
              background: "linear-gradient(90deg, #00ff88, #00bbff)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              letterSpacing: "-0.5px",
            }}>EV Lock</div>
            <div style={{ fontSize: 11, color: "#5a6a80", letterSpacing: "1.5px", textTransform: "uppercase", marginTop: -2 }}>
              Auto-Hedge Engine for Polymarket
            </div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 6,
            background: isRunning ? "rgba(0,255,136,0.08)" : "rgba(255,68,102,0.08)",
            border: `1px solid ${isRunning ? "rgba(0,255,136,0.2)" : "rgba(255,68,102,0.2)"}`,
            borderRadius: 8, padding: "6px 12px", fontSize: 12, fontWeight: 600,
          }}>
            <div style={{
              width: 7, height: 7, borderRadius: "50%",
              background: isRunning ? "#00ff88" : "#ff4466",
              animation: isRunning ? "pulse 1.5s infinite" : "none",
            }} />
            <span style={{ color: isRunning ? "#00ff88" : "#ff4466" }}>
              {isRunning ? "LIVE" : "PAUSED"}
            </span>
          </div>
          <button className="btn" onClick={() => setIsRunning(!isRunning)} style={{
            background: "#1a2030", color: "#c0c8d8", padding: "6px 14px", fontSize: 12,
          }}>
            {isRunning ? "⏸ Pause" : "▶ Start"}
          </button>
          <select value={simSpeed} onChange={e => setSimSpeed(Number(e.target.value))} style={{
            background: "#1a2030", color: "#c0c8d8", border: "1px solid #2a3545",
            borderRadius: 8, padding: "6px 10px", fontSize: 12, fontFamily: "inherit",
          }}>
            <option value={0.5}>0.5×</option>
            <option value={1}>1×</option>
            <option value={2}>2×</option>
            <option value={4}>4×</option>
          </select>
        </div>
      </div>

      <div style={{ padding: "20px 24px", maxWidth: 1400, margin: "0 auto" }}>

        {/* Stats Cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 20 }}>
          {[
            { label: "Portfolio Value", value: formatMoney(totalValue), sub: formatMoney(totalCost) + " cost basis", color: "#00bbff" },
            { label: "Unrealized P&L", value: formatMoney(totalPnL), sub: formatPct(totalPnL / totalCost), color: totalPnL >= 0 ? "#00ff88" : "#ff4466" },
            { label: "Free Roll Profit", value: formatMoney(totalLocked), sub: `${hedgedCount}/${markets.length} hedged`, color: "#ffd700" },
            { label: "Auto-Hedge", value: autoHedge ? "ACTIVE" : "OFF", sub: `Threshold: ${hedgeThreshold}%`, color: autoHedge ? "#00ff88" : "#5a6a80" },
          ].map((c, i) => (
            <div key={i} className="card" style={{ padding: "16px 18px", animation: `slideIn 0.3s ease ${i * 0.05}s both` }}>
              <div style={{ fontSize: 11, color: "#5a6a80", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 6 }}>{c.label}</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: c.color, fontFamily: "'JetBrains Mono', monospace" }}>{c.value}</div>
              <div style={{ fontSize: 12, color: "#4a5a6a", marginTop: 4 }}>{c.sub}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
          {["portfolio", "settings", "activity"].map(t => (
            <button key={t} className="btn" onClick={() => setTab(t)} style={{
              background: tab === t ? "#1a2535" : "transparent",
              color: tab === t ? "#00ff88" : "#5a6a80",
              padding: "8px 18px", fontSize: 13,
              borderBottom: tab === t ? "2px solid #00ff88" : "2px solid transparent",
              borderRadius: "8px 8px 0 0",
            }}>
              {t === "portfolio" ? "📊 Positions" : t === "settings" ? "⚙ Hedge Settings" : "📋 Activity Log"}
            </button>
          ))}
        </div>

        {/* Portfolio Tab */}
        {tab === "portfolio" && (
          <div style={{ display: "grid", gridTemplateColumns: selectedMarket ? "1fr 380px" : "1fr", gap: 16 }}>
            <div className="card" style={{ overflow: "hidden" }}>
              <div style={{
                display: "grid",
                gridTemplateColumns: "44px 2fr 80px 100px 100px 100px 90px 120px",
                padding: "10px 16px",
                fontSize: 11,
                color: "#4a5a6a",
                textTransform: "uppercase",
                letterSpacing: "0.8px",
                borderBottom: "1px solid #1a2030",
                background: "#0d1220",
              }}>
                <div></div>
                <div>Market</div>
                <div>Chart</div>
                <div style={{ textAlign: "right" }}>Entry</div>
                <div style={{ textAlign: "right" }}>Current</div>
                <div style={{ textAlign: "right" }}>P&L</div>
                <div style={{ textAlign: "center" }}>Status</div>
                <div style={{ textAlign: "center" }}>Action</div>
              </div>
              {markets.map((m, i) => {
                const cost = m.entryPrice * m.shares;
                const val = m.currentPrice * m.shares;
                const pnl = val - cost;
                const pnlPct = pnl / cost;
                const isHedged = !!hedgedPositions[m.id];
                const hedge = calcHedge(m.entryPrice, m.currentPrice, m.shares, m.side);
                const canHedge = hedge && hedge.guaranteedProfit > 0;

                return (
                  <div key={m.id} className="row-hover" onClick={() => setSelectedMarket(selectedMarket === m.id ? null : m.id)} style={{
                    display: "grid",
                    gridTemplateColumns: "44px 2fr 80px 100px 100px 100px 90px 120px",
                    padding: "12px 16px",
                    alignItems: "center",
                    borderBottom: "1px solid #111d2a",
                    cursor: "pointer",
                    animation: `slideIn 0.3s ease ${i * 0.04}s both`,
                    background: selectedMarket === m.id ? "#151d2e" : "transparent",
                    transition: "background 0.15s",
                  }}>
                    <div style={{ fontSize: 22 }}>{m.emoji}</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.3, color: "#d0d8e8" }}>{m.name}</div>
                      <div style={{ fontSize: 11, color: "#4a5a6a", marginTop: 2 }}>
                        {m.shares} shares · {m.side} · {m.category}
                      </div>
                    </div>
                    <MiniSparkline history={priceHistory[m.id]} />
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 13, fontFamily: "'JetBrains Mono', monospace", color: "#8090a0" }}>
                        {(m.entryPrice * 100).toFixed(1)}¢
                      </div>
                      <div style={{ fontSize: 11, color: "#4a5a6a" }}>{formatMoney(cost)}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <PriceTicker price={m.currentPrice} prev={prevPrices[m.id]} />
                      <div style={{ fontSize: 11, color: "#4a5a6a" }}>{formatMoney(val)}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{
                        fontSize: 13, fontWeight: 600,
                        fontFamily: "'JetBrains Mono', monospace",
                        color: pnl >= 0 ? "#00ff88" : "#ff4466",
                      }}>
                        {formatMoney(pnl)}
                      </div>
                      <div style={{ fontSize: 11, color: pnl >= 0 ? "#00cc6a" : "#cc3355" }}>
                        {formatPct(pnlPct)}
                      </div>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      {isHedged ? (
                        <span style={{
                          background: "rgba(255,215,0,0.1)", color: "#ffd700",
                          padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                          border: "1px solid rgba(255,215,0,0.2)",
                          animation: "glow 2s infinite",
                        }}>LOCKED</span>
                      ) : canHedge ? (
                        <span style={{
                          background: "rgba(0,255,136,0.08)", color: "#00ff88",
                          padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                          border: "1px solid rgba(0,255,136,0.15)",
                        }}>READY</span>
                      ) : (
                        <span style={{
                          background: "rgba(90,106,128,0.1)", color: "#5a6a80",
                          padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                        }}>WAIT</span>
                      )}
                    </div>
                    <div style={{ textAlign: "center" }}>
                      {isHedged ? (
                        <button className="btn" onClick={(e) => { e.stopPropagation(); removeHedge(m.id); }} style={{
                          background: "rgba(255,68,102,0.1)", color: "#ff4466",
                          padding: "5px 12px", fontSize: 11, border: "1px solid rgba(255,68,102,0.2)",
                        }}>Remove</button>
                      ) : canHedge ? (
                        <button className="btn" onClick={(e) => { e.stopPropagation(); manualHedge(m); }} style={{
                          background: "linear-gradient(135deg, #00ff88, #00cc6a)",
                          color: "#0a0e17", padding: "5px 12px", fontSize: 11,
                        }}>Hedge Now</button>
                      ) : (
                        <span style={{ fontSize: 11, color: "#3a4a5a" }}>—</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Detail Panel */}
            {selected && (
              <div className="card" style={{ padding: 20, animation: "slideIn 0.2s ease", height: "fit-content" }}>
                <div style={{ fontSize: 11, color: "#4a5a6a", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>
                  Position Detail
                </div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#e0e8f0", marginBottom: 4 }}>
                  {selected.emoji} {selected.name}
                </div>
                <div style={{ fontSize: 12, color: "#5a6a80", marginBottom: 16 }}>{selected.shares} {selected.side} shares</div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 18 }}>
                  {[
                    { l: "Entry Price", v: `${(selected.entryPrice * 100).toFixed(1)}¢` },
                    { l: "Current Price", v: `${(selected.currentPrice * 100).toFixed(1)}¢` },
                    { l: "Cost Basis", v: formatMoney(selected.entryPrice * selected.shares) },
                    { l: "Market Value", v: formatMoney(selected.currentPrice * selected.shares) },
                  ].map((item, i) => (
                    <div key={i} style={{ background: "#0d1220", borderRadius: 8, padding: "10px 12px" }}>
                      <div style={{ fontSize: 10, color: "#4a5a6a", textTransform: "uppercase" }}>{item.l}</div>
                      <div style={{ fontSize: 15, fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", color: "#c0c8d8", marginTop: 2 }}>{item.v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ borderTop: "1px solid #1a2535", paddingTop: 16 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "#8090a0", marginBottom: 12 }}>
                    {selectedHedged ? "🎰 Free Roll Active" : "Hedge Calculator"}
                  </div>
                  {selectedHedged ? (
                    <div>
                      <div style={{ background: "rgba(255,215,0,0.05)", border: "1px solid rgba(255,215,0,0.15)", borderRadius: 10, padding: 14 }}>
                        <div style={{ fontSize: 11, color: "#5a6a80", marginBottom: 4 }}>Free Roll — Max Profit If Win</div>
                        <div style={{ fontSize: 22, fontWeight: 700, color: "#ffd700", fontFamily: "'JetBrains Mono', monospace" }}>
                          {formatMoney(selectedHedged.guaranteedProfit)}
                        </div>
                        <div style={{ fontSize: 11, color: "#5a6a80", marginTop: 8 }}>
                          Hedge: {selectedHedged.hedgeSide} ${selectedHedged.hedgeStake.toFixed(2)} @ {(selectedHedged.hedgePrice * 100).toFixed(1)}¢
                        </div>
                        <div style={{ fontSize: 11, color: "#4a5a6a", marginTop: 2 }}>
                          Locked at {selectedHedged.timestamp}
                        </div>
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 10 }}>
                        <div style={{ background: "#0d1220", borderRadius: 8, padding: 10 }}>
                          <div style={{ fontSize: 10, color: "#00ff88" }}>✓ If {selected.side} wins</div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: "#00ff88", fontFamily: "'JetBrains Mono', monospace" }}>
                            {formatMoney(selectedHedged.ifOriginalWins)}
                          </div>
                        </div>
                        <div style={{ background: "#0d1220", borderRadius: 8, padding: 10 }}>
                          <div style={{ fontSize: 10, color: "#8090a0" }}>✓ If {selected.side} loses</div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: "#8090a0", fontFamily: "'JetBrains Mono', monospace" }}>
                            $0.00
                          </div>
                          <div style={{ fontSize: 9, color: "#4a5a6a" }}>break-even</div>
                        </div>
                      </div>
                    </div>
                  ) : selectedHedge ? (
                    <div>
                      <div style={{ background: "rgba(0,255,136,0.05)", border: "1px solid rgba(0,255,136,0.1)", borderRadius: 10, padding: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <div>
                            <div style={{ fontSize: 11, color: "#5a6a80" }}>Profit If Win (Free Roll)</div>
                            <div style={{ fontSize: 22, fontWeight: 700, color: "#00ff88", fontFamily: "'JetBrains Mono', monospace" }}>
                              {formatMoney(selectedHedge.guaranteedProfit)}
                            </div>
                          </div>
                          <ProgressRing pct={selectedHedge.roi} size={48} stroke={4} />
                        </div>
                        <div style={{ fontSize: 11, color: "#5a6a80", marginTop: 6 }}>
                          Place {selectedHedge.hedgeSide} ${selectedHedge.hedgeStake.toFixed(2)} @ {(selectedHedge.hedgePrice * 100).toFixed(1)}¢
                        </div>
                        <div style={{ fontSize: 11, color: "#4a5a6a", marginTop: 2 }}>
                          ROI: {(selectedHedge.roi * 100).toFixed(1)}% · vs {formatMoney(selectedHedge.profitIfNoHedge)} unhedged · $0 if lose
                        </div>
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 10 }}>
                        <div style={{ background: "#0d1220", borderRadius: 8, padding: 10 }}>
                          <div style={{ fontSize: 10, color: "#00ff88" }}>✓ If {selected.side} wins</div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: "#00ff88", fontFamily: "monospace" }}>{formatMoney(selectedHedge.ifOriginalWins)}</div>
                        </div>
                        <div style={{ background: "#0d1220", borderRadius: 8, padding: 10 }}>
                          <div style={{ fontSize: 10, color: "#8090a0" }}>✓ If {selected.side} loses</div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: "#8090a0", fontFamily: "monospace" }}>$0.00</div>
                          <div style={{ fontSize: 9, color: "#4a5a6a" }}>break-even</div>
                        </div>
                      </div>
                      <button className="btn" onClick={() => manualHedge(selected)} style={{
                        width: "100%", marginTop: 12,
                        background: "linear-gradient(135deg, #00ff88, #00cc6a)",
                        color: "#0a0e17", padding: "10px 0", fontSize: 13,
                      }}>
                        🎰 Go Free Roll
                      </button>
                    </div>
                  ) : (
                    <div style={{ color: "#4a5a6a", fontSize: 13, textAlign: "center", padding: 20 }}>
                      Price hasn't moved enough to hedge profitably yet. Waiting for favorable movement…
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Settings Tab */}
        {tab === "settings" && (
          <div className="card" style={{ padding: 24, maxWidth: 600, animation: "slideIn 0.2s ease" }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#e0e8f0", marginBottom: 20 }}>Auto-Hedge Parameters</div>

            <div style={{ marginBottom: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "#c0c8d8" }}>Enable Auto-Hedge</div>
                  <div style={{ fontSize: 12, color: "#5a6a80" }}>Automatically place hedge orders when conditions are met</div>
                </div>
                <div onClick={() => setAutoHedge(!autoHedge)} style={{
                  width: 48, height: 26, borderRadius: 13, cursor: "pointer",
                  background: autoHedge ? "#00ff88" : "#2a3545",
                  transition: "background 0.2s",
                  display: "flex", alignItems: "center", padding: "0 3px",
                }}>
                  <div style={{
                    width: 20, height: 20, borderRadius: "50%", background: "#fff",
                    transform: autoHedge ? "translateX(22px)" : "translateX(0)",
                    transition: "transform 0.2s",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
                  }} />
                </div>
              </div>
            </div>

            <div style={{ marginBottom: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#c0c8d8" }}>Price Move Threshold</div>
                <span style={{ fontSize: 14, fontFamily: "'JetBrains Mono', monospace", color: "#00ff88" }}>{hedgeThreshold}%</span>
              </div>
              <div style={{ fontSize: 12, color: "#5a6a80", marginBottom: 10 }}>Minimum price increase from entry before hedging triggers</div>
              <input type="range" min={5} max={50} value={hedgeThreshold} onChange={e => setHedgeThreshold(Number(e.target.value))}
                style={{ width: "100%", accentColor: "#00ff88" }} />
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#3a4a5a", marginTop: 4 }}>
                <span>5% (Aggressive)</span><span>50% (Conservative)</span>
              </div>
            </div>

            <div style={{ marginBottom: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#c0c8d8" }}>Min Profit If Win</div>
                <span style={{ fontSize: 14, fontFamily: "'JetBrains Mono', monospace", color: "#00ff88" }}>${minProfit}</span>
              </div>
              <div style={{ fontSize: 12, color: "#5a6a80", marginBottom: 10 }}>Don't hedge unless this profit-if-win amount is achievable</div>
              <input type="range" min={1} max={100} value={minProfit} onChange={e => setMinProfit(Number(e.target.value))}
                style={{ width: "100%", accentColor: "#00ff88" }} />
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#3a4a5a", marginTop: 4 }}>
                <span>$1</span><span>$100</span>
              </div>
            </div>

            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: "#c0c8d8", marginBottom: 8 }}>Hedge Strategy</div>
              <div style={{
                padding: "14px 16px", borderRadius: 10,
                background: "rgba(0,255,136,0.08)",
                border: "1px solid rgba(0,255,136,0.3)",
              }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#00ff88" }}>Max If Win (Free Roll)</div>
                <div style={{ fontSize: 12, color: "#7a9a8a", marginTop: 6, lineHeight: 1.5 }}>
                  Hedges the minimum amount to eliminate all downside risk. If your original bet loses, you break even ($0 loss).
                  If it wins, you keep maximum profit minus the small hedge cost. Converts your position into a free roll with zero risk.
                </div>
              </div>
            </div>

            <div style={{
              background: "rgba(0,187,255,0.05)", border: "1px solid rgba(0,187,255,0.15)",
              borderRadius: 10, padding: 14, fontSize: 12, color: "#6090b0",
            }}>
              <strong style={{ color: "#00bbff" }}>ℹ How it works:</strong> EV Lock monitors your Polymarket positions in real-time.
              When the implied probability moves in your favor beyond your threshold, it calculates the minimum hedge
              on the opposite side to guarantee $0 loss. You keep maximum upside — if your bet wins, you profit.
              If it loses, you walk away even. This is known as a "free roll" position.
            </div>
          </div>
        )}

        {/* Activity Tab */}
        {tab === "activity" && (
          <div className="card" style={{ overflow: "hidden", animation: "slideIn 0.2s ease" }}>
            <div style={{
              padding: "12px 16px", borderBottom: "1px solid #1a2030",
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#8090a0" }}>
                {activityLog.length} events
              </span>
              <button className="btn" onClick={() => setActivityLog([])} style={{
                background: "#1a2030", color: "#5a6a80", padding: "5px 12px", fontSize: 11,
              }}>Clear</button>
            </div>
            <div ref={logRef} style={{ maxHeight: 420, overflowY: "auto" }}>
              {activityLog.length === 0 ? (
                <div style={{ padding: 40, textAlign: "center", color: "#3a4a5a", fontSize: 13 }}>
                  No activity yet. Start the simulation and enable auto-hedge to see events here.
                </div>
              ) : activityLog.map((log) => (
                <div key={log.id} style={{
                  padding: "10px 16px",
                  borderBottom: "1px solid #111d2a",
                  display: "flex", gap: 12, alignItems: "flex-start",
                  animation: "slideIn 0.2s ease",
                }}>
                  <div style={{
                    width: 8, height: 8, borderRadius: "50%", marginTop: 5, flexShrink: 0,
                    background: log.type === "hedge" ? "#ffd700" : log.type === "error" ? "#ff4466" : log.type === "warn" ? "#ff9900" : "#00bbff",
                  }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: "#c0c8d8", lineHeight: 1.4 }}>{log.msg}</div>
                    <div style={{ fontSize: 10, color: "#3a4a5a", marginTop: 2 }}>{log.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
